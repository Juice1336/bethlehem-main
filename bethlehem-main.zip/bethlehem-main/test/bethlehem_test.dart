import 'package:bethlehem/bethlehem.dart';
import 'package:test/test.dart';

void main() {
  group('A group of tests', () {
    //Awesome awesome;

    setUp(() {
      //awesome = Awesome();
    });

    test('First Test', () {
      // expect(awesome.isAwesome, isTrue);
    });
  });
}
