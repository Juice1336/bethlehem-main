## 1.0.0-dev.1

- Initial version, created by D.I.E.N

## 1.0.1-dev.1

- Removed the component loader object from the AngularView constructor and made it internal to improve usability
- Changed The Readme example to refelect this change

## 1.0.11-dev.1

- Added a better description in the pubspec file

## 1.0.12-dev.1

- Converted AngularView Placeholder into a function that returns the placeholder to allow for setup

## 1.0.13-dev.1

- Giving total control of loading the view to the object passed in by the user to the AngularView instance

## 1.0.14-dev.1

- Fixed a few bugs

## 1.0.15-dev.1

- Returning the loader to objectController to destroy view when url change occurs

## 1.0.16-dev.1

- Fixed a few bugs

## 1.0.17-dev.1

- Fixed a few bugs

## 1.0.18-dev.1

- Fixed a few bugs

## 1.0.19-dev.1

- Fixed a few bugs

## 1.0.20-dev.1

- Fixed a few bugs

## 1.0.21-dev.1

- Fixed a few bugs

## 1.0.22-dev.1

- Exported the router state class to get parameters from router
