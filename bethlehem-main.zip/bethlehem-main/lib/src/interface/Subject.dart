import 'package:bethlehem/src/interface/Observer.dart';

class Subject {
  void register(Observer observer) {}
}
