class Observer {
  void update(dynamic msg) {}
}
