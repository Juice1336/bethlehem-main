class RoadPath {
  String path;
  RoadPath({this.path});
}
