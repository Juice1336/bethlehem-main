import 'package:bethlehem/src/road/road_path.dart';

final dashboard = RoadPath(path: 'dashboard');
